
<footer class="py-4 footer-bg">
     <div class="container text-center">
       <div class="row align-items-center">
         <?php if(is_active_sidebar('juliette_footer')){
                     dynamic_sidebar('juliette_footer');
                 }?>
         <div class="col-md-4 text-center">
           <div class="d-flex align-items-center flex-wrap justify-content-center">
             <h6 class="text-muted mb-0 py-2 mr-3"><?php _e('Follow me', 'juliette-wp');?><span class="ml-3">-</span></h6>
            <ul class="list-inline small mb-0 text-dark d-none d-lg-block">       
            <li class="list-inline-item"><a class="reset-anchor" href="<?php echo esc_url(get_theme_mod('set_facebook' ));?>"><i class="fab fa-facebook-f"></i></a></li>
             <li class="list-inline-item"><a class="reset-anchor" href="<?php echo esc_url( get_theme_mod('set_twitter'));?>"><i class="fab fa-twitter"></i></a></li>
             <li class="list-inline-item"><a class="reset-anchor" href="<?php echo esc_url( get_theme_mod('set_instagram'));?>"><i class="fab fa-instagram"></i></a></li>
             <li class="list-inline-item"><a class="reset-anchor" href="<?php echo esc_url (get_theme_mod('set_linkedin'));?>"><i class="fab fa-linkedin"></i></a></li>
             <li class="list-inline-item"><a class="reset-anchor" href="<?php echo esc_url(get_theme_mod('set_youtube'));?>"><i class="fab fa-youtube"></i></a></li>
          </ul>

           </div>
         </div>
         <div class="col-md-4 text-lg-right">
           <?php if(get_theme_mod('set_copyright')):?>
            <p class="mb-0 text-muted text-small text-heading"> </p>
              <p class="mb-0 text-muted text-small text-heading">
                <?php echo esc_html(get_theme_mod('set_copyright'));?>
              <a target="_blank" href="<?php echo esc_url( __( 'https://bootstraptemple.com/p/juliette', 'juliette-wp' ) ); ?>">
                <?php _e( 'Designed by Bootstrap Temple', 'juliette-wp' ); ?>
              </a>
              &
               <a target="_blank" href="<?php echo esc_url( __( 'https://95media.co.uk', 'juliette-wp' ) ); ?>">
                <?php _e( '95media', 'juliette-wp' ); ?>
              </a>
            </p>
           
             
         <?php endif;?>
         </div>
       </div>
     </div>
   </footer>

<?php wp_footer();?>

</body>
</html>
