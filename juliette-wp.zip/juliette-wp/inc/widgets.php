<?php

 /*

@package

Juliette

Wigdets

 */


function juliette_theme_widgets(){
  register_sidebar([
        'name'              => __('Juliette Sidebar Widgets', 'juliette-wp'),
        'id'                => 'juliette_sidebar',
        'description'       => __('Sidebar for the theme juliette', 'juliette-wp'),
        'before_widget'     => '<div id="%1$s" class=" card-body p-0 widget %2$s">',
        'after_widget'      => '</div>',
        'before_title'      => '<h2 class="h5 mb-3 mt-3">',
        'after_title'       => '</h2>'
    ]);

    register_sidebar([
          'name'              => __('Juliette Footer Widgets', 'juliette-wp'),
          'id'                => 'juliette_footer',
          'description'       => __('Footer Sidebar for the theme juliette', 'juliette-wp'),
          'before_widget'     => '<div id="%1$s" class=" col-md-4 text-lg-left p-0 widget %2$s">',
          'after_widget'      => '</div>',
          'before_title'      => '<h2 class="h5 mb-3">',
          'after_title'       => '</h2>'
      ]);
}
