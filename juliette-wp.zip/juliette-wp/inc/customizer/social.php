<?php
/**
 * Juliette Theme Customizer
 *
 * @package Juliette
 */

function juliette_customizer( $wp_customize ){



// facebook

$wp_customize->add_section(
  'sec_social', array(
    'title' 		=> __( 'Social Media Section', 'juliette-wp'),
    'description' 	=> __( 'Social Section', 'juliette-wp' )
  )
);

    // Field 1 - Facebook Text Box
    $wp_customize->add_setting(
      'set_facebook', array(
        'type' 				=> 'theme_mod',
        'default' 			=> '',
        'sanitize_callback' => 'esc_url_raw'
      )
    );

    $wp_customize->add_control(
      'set_facebook', array(
        'label' 		=> __( 'Facebook', 'juliette-wp' ),
        'description' 	=> __( 'Please add your facebook page link here', 'juliette-wp' ),
        'section' 		=> 'sec_social',
        'type' 			=> 'url'
      )
    );

    // Field 2 - Twitter Text Box
    $wp_customize->add_setting(
      'set_twitter', array(
        'type' 				=> 'theme_mod',
        'default' 			=> '',
        'sanitize_callback' => 'esc_url_raw'
      )
    );

    $wp_customize->add_control(
      'set_twitter', array(
        'label' 		=> __( 'Twitter', 'juliette-wp' ),
        'description' 	=> __( 'Please add your twitter handle here', 'juliette-wp' ),
        'section' 		=> 'sec_social',
        'type' 			=> 'url'
      )
    );


    // Field 3 - Twitter Text Box
    $wp_customize->add_setting(
      'set_instagram', array(
        'type' 				=> 'theme_mod',
        'default' 			=> '',
        'sanitize_callback' => 'esc_url_raw'
      )
    );

    $wp_customize->add_control(
      'set_instagram', array(
        'label' 		=> __( 'Instagram', 'juliette-wp' ),
        'description' 	=> __( 'Please add your Instagram handle here', 'juliette-wp' ),
        'section' 		=> 'sec_social',
        'type' 			=> 'esc_url_raw'
      )
    );

    // Field 4 - Linkedin Text Box
    $wp_customize->add_setting(
      'set_linkedin', array(
        'type' 				=> 'theme_mod',
        'default' 			=> '',
        'sanitize_callback' => 'esc_url_raw'
      )
    );

    $wp_customize->add_control(
      'set_linkedin', array(
        'label' 		=> __( 'LinkedIn', 'juliette-wp' ),
        'description' 	=> __( 'Please add your LinkedIn page here', 'juliette-wp' ),
        'section' 		=> 'sec_social',
        'type' 			=> 'url'
      )
    );


    // Field 5 - Youtube Text Box
    $wp_customize->add_setting(
      'set_youtube', array(
        'type' 				=> 'theme_mod',
        'default' 			=> '',
        'sanitize_callback' => 'esc_url_raw'
      )
    );

    $wp_customize->add_control(
      'set_youtube', array(
        'label' 		=> __( 'Youtube', 'juliette-wp' ),
        'description' 	=> __( 'Please add your Youtube page here', 'juliette-wp' ),
        'section' 		=> 'sec_social',
        'type' 			=> 'url'
      )
    );


        // Field 5 - Email Text Box
        $wp_customize->add_setting(
          'set_email', array(
            'type' 				=> 'theme_mod',
            'default' 			=> '',
            'sanitize_callback' => 'sanitize_email'
          )
        );

        $wp_customize->add_control(
          'set_email', array(
            'label' 		=> __( 'Email Address', 'juliette-wp' ),
            'description' 	=> __( 'Please add your Address here', 'juliette-wp' ),
            'section' 		=> 'sec_social',
            'type' 			=> 'email'
          )
        );



	// Copyright Section

	$wp_customize->add_section(
		'sec_copyright', array(
			'title' 		=> __( 'Copyright Settings', 'juliette-wp'),
			'description' 	=> __( 'Copyright Section', 'juliette-wp' )
		)
	);

			// Field 1 - Copyright Text Box
			$wp_customize->add_setting(
				'set_copyright', array(
					'type' 				=> 'theme_mod',
					'default' 			=> '',
					'sanitize_callback' => 'sanitize_text_field'
				)
			);

			$wp_customize->add_control(
				'set_copyright', array(
					'label' 		=> __( 'Copyright', 'juliette-wp' ),
					'description' 	=> __( 'Please, add your copyright information here', 'juliette-wp' ),
					'section' 		=> 'sec_copyright',
					'type' 			=> 'text'
				)
			);

}
add_action( 'customize_register', 'juliette_customizer' );

function fancy_lab_sanitize_checkbox( $checked ){
    //returns true if checkbox is checked
    return ( ( isset( $checked ) && true == $checked ) ? true : false );
}
