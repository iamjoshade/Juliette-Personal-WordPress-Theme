<?php

function juliette_newsletter($wp_customize){



      $wp_customize->add_section(
        'juliette_newsletter_section', array(
          'title' 		=> __( 'Newsletter Section', 'juliette-wp'),
          'description' 	=> __( 'Newsletter  Section', 'juliette-wp' ),
          'panel'   => 'juliette'
        )
      );


       // Check if newsletter is active
        $wp_customize->add_setting(
            'show_newsletter', array(
                'type' 				=> 'theme_mod',
                'default' 			=> '',
                'sanitize_callback' => 'juliette_sanitize_checkbox' 
            )
        );

        $wp_customize->add_control(
            'show_newsletter', array(
                'label' 	=> __( 'Check to show newsletter', 'juliette-wp' ),
                'section' 	=> 'juliette_newsletter_section',
                'type' 		=> 'checkbox'			
            )
        );


        $wp_customize->add_setting('subscribe_form_title',
            array(
                'default' => '',
                'sanitize_callback' => 'sanitize_text_field',
            )
        );
        $wp_customize->add_control('subscribe_form_title',
            array(
                'label' => esc_html__('Subscribe Section Title', 'juliette-wp'),
                'section' => 'juliette_newsletter_section',
                'type' => 'text',
            )
        );

        $wp_customize->add_setting('subscribe_form_description',
    array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    )
);
$wp_customize->add_control('subscribe_form_description',
    array(
        'label' => esc_html__('Subscribe Section Description', 'juliette-wp'),
        'section' => 'juliette_newsletter_section',
        'type' => 'text',
    )
);

    $wp_customize->add_setting('subscribe_form_shortcode',
        array(
            'default' => '',
            'sanitize_callback' => 'sanitize_text_field',
        )
    );
    $wp_customize->add_control('subscribe_form_shortcode',
        array(
            'label' => esc_html__('Subscribe Form Shortcode', 'juliette-wp'),
            'description' => esc_html__('Please install "MC4WP Plugin:, and paste your generated shortcode below', 'juliette-wp'),
            'section' => 'juliette_newsletter_section',
            'type' => 'text',
        )
    );

}