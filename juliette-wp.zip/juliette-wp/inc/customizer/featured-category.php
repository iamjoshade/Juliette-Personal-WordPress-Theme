<?php

function juliette_featured_category($wp_customize){

      // Featured Category
      $juliette_cat_list = juliette_category_list();

      $wp_customize->add_section(
        'juliette_featured_category', array(
          'title' 		=> __( 'Featured Category', 'juliette-wp'),
          'description' 	=> __( 'Featured Category Section', 'juliette-wp' ),
          'panel'   => 'juliette'
        )
      );


       // Check if Featured category is active
 $wp_customize->add_setting(
    'show_featured_category', array(
        'type' 				=> 'theme_mod',
        'default' 			=> '0',
        'sanitize_callback' => 'juliette_sanitize_checkbox'
    )
);

$wp_customize->add_control(
    'show_featured_category', array(
        'label' 	=> __( 'Check to show featured category', 'juliette-wp' ),
        'section' 	=> 'juliette_featured_category',
        'type' 		=> 'checkbox'
    )
);


$wp_customize->add_setting('juliette_featured_category_1',
    array(
        'default' => '0',
        'sanitize_callback' => 'juliette_sanitize_category',
    )
);
$wp_customize->add_control('juliette_featured_category_1',
    array(
        'label' => esc_html__('Featured Category One', 'juliette-wp'),
        'section' => 'juliette_featured_category',
        'type' => 'select',
        'choices' => $juliette_cat_list,
    )
);


$wp_customize->add_setting('juliette_featured_category_2',
    array(
        'default' => '0',
        'sanitize_callback' => 'juliette_sanitize_category',
    )
);
$wp_customize->add_control('juliette_featured_category_2',
    array(
        'label' => esc_html__('Featured Category Two', 'juliette-wp'),
        'section' => 'juliette_featured_category',
        'type' => 'select',
        'choices' => $juliette_cat_list,
    )
);

$wp_customize->add_setting('juliette_featured_category_3',
    array(
        'default' => '0',
        'sanitize_callback' => 'juliette_sanitize_category',
    )
);
$wp_customize->add_control('juliette_featured_category_3',
    array(
        'label' => esc_html__('Featured Category Three', 'juliette-wp'),
        'section' => 'juliette_featured_category',
        'type' => 'select',
        'choices' => $juliette_cat_list,
    )
);


}

function juliette_sanitize_checkbox( $checked ){
    //returns true if checkbox is checked
    return ( ( isset( $checked ) && true == $checked ) ? true : false );
}

if( !function_exists('juliette_category_list') ):

	/** Post Category List **/
	function juliette_category_list(){
	    $cat_lists = get_categories(
	        array(
	            'hide_empty' => '0',
	            'exclude' => '1',
	        )
	    );
	    $cat_array = array();
	    $cat_array[] = esc_html__('--Choose Category--','juliette-wp');
	    foreach( $cat_lists as $cat_list ){
	        $cat_array[$cat_list->slug] = $cat_list->name;
	    }
	    return $cat_array;
	}

endif;


if( !function_exists('juliette_sanitize_category') ):

	/**
	* Customizer Category Sanitize
	**/

	function juliette_sanitize_category($input){

	    $juliette_Category_list = juliette_category_list();

	    if(array_key_exists($input,$juliette_Category_list)){
	        return $input;
	    }
	    else{
	        return '';
	    }
	}

endif;
