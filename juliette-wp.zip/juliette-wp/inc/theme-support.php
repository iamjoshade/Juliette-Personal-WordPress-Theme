<?php



add_action( 'add_meta_boxes', 'juliette_author_namme_add_meta_box', 10, 2 );
 
function juliette_author_namme_add_meta_box() {
	add_meta_box( 'author_name', 'Author Name', 'juliette_author_name_callback', 'juliette-quote', 'side' );
}


function juliette_author_name_callback( $post ) {
	wp_nonce_field( 'juliette_save_author_name_data', 'juliette_author_name_meta_box_nonce' );
	
	$value = get_post_meta( $post->ID, '_author_name_value_key', true );
	
	echo '<label for="juliette_author_name_field">User Email Address: </lable>';
	echo '<input type="text" id="juliette_author_name_field" name="juliette_author_name_field" value="' . esc_attr( $value ) . '" size="25" />';
}

function juliette_save_author_name_data( $post_id ) {
	
	if( ! isset( $_POST['juliette_author_name_meta_box_nonce'] ) ){
		return;
	}
	
	if( ! wp_verify_nonce( $_POST['juliette_author_name_meta_box_nonce'], 'juliette_save_author_name_data') ) {
		return;
	}
	
	if( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ){
		return;
	}
	
	if( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	
	if( ! isset( $_POST['juliette_author_name_field'] ) ) {
		return;
	}
	
	$my_data = sanitize_text_field( $_POST['juliette_author_name_field'] );
	
	update_post_meta( $post_id, '_author_name_value_key', $my_data );
	
}
add_action( 'save_post', 'juliette_save_author_name_data' );








 /*
    @package Juliette
    displaying post category
 */
 function juliette_category_class($thelist){
   $categories = get_the_category();

   if ( !$categories || is_wp_error($categories) ) {
     return $thelist;
   }

   $output ='';
   foreach ( $categories as $category ) {
     $output .= '<li class="list-inline-item mr-2"><a class="category-link font-weight-normal" href="' . esc_url(get_category_link($category->term_id)) . '">' . $category->name . '</a></li>';
   }


   return $output;
 }
 add_filter( 'the_category', 'juliette_category_class');

 function juliette_class_the_tags($html){
     $postid = get_the_ID();
     $html = str_replace('<a','<a class="sidebar-tag-link"',$html);
     return $html;
 }
 add_filter('the_tags','juliette_class_the_tags',10,1);

/*

@package Juliette

	========================
		REMOVE GENERATOR VERSION NUMBER
	========================
*/

/* remove version string from js and css */
function juliette_remove_wp_version_strings( $src ) {

global $wp_version;
parse_str( parse_url($src, PHP_URL_QUERY), $query );
if ( !empty( $query['ver'] ) && $query['ver'] === $wp_version ) {
  $src = remove_query_arg( 'ver', $src );
}
return $src;

}
add_filter( 'script_loader_src', 'juliette_remove_wp_version_strings' );
add_filter( 'style_loader_src', 'juliette_remove_wp_version_strings' );

/* remove metatag generator from header */
function juliette_remove_meta_version() {
return '';
}
add_filter( 'the_generator', 'juliette_remove_meta_version' );



/* Recent Post Extention */
/**
 * Extend Recent Posts Widget
 *
 * Adds different formatting to the default WordPress Recent Posts Widget
 */

Class Juliette_Recent_Posts_Widget extends WP_Widget_Recent_Posts {

        function widget($args, $instance) {

                if ( ! isset( $args['widget_id'] ) ) {
                $args['widget_id'] = $this->id;
            }

            $title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Recent Posts', 'juliette-wp' );

            /** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
            $title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

            $number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 5;
            if ( ! $number )
                $number = 5;
            $show_date = isset( $instance['show_date'] ) ? $instance['show_date'] : false;

            /**
             * Filter the arguments for the Recent Posts widget.
             *
             * @since 3.4.0
             *
             * @see WP_Query::get_posts()
             *
             * @param array $args An array of arguments used to retrieve the recent posts.
             */
            $r = new WP_Query( apply_filters( 'widget_posts_args', array(
                'posts_per_page'      => $number,
                'no_found_rows'       => true,
                'post_status'         => 'publish',
                'ignore_sticky_posts' => true
            ) ) );

            if ($r->have_posts()) :
            ?>
            <?php echo $args['before_widget']; ?>
            <?php if ( $title ) {
                echo $args['before_title'] . $title . $args['after_title'];
            } ?>

            <?php while ( $r->have_posts() ) : $r->the_post();
              $recent_post_image = get_the_post_thumbnail_url();
             ?>

                <div class="media mb-3">
                  <?php if(!empty($recent_post_image)) : ?>
                    <a class="d-block" href="<?php the_permalink();?>">
                    <img class="img-fluid blog-post-recent-post" src="<?php echo $recent_post_image; ?>">
                  </a>

                  <?php else:?>
                   <a class="d-block" href="<?php the_permalink();?>">
                   <img class="img-fluid" src="https://place-hold.it/70x63" alt="" width="70">
                  </a>
                <?php endif?>
                  <div class="media-body ml-3">
                    <h6> <a class="reset-anchor" href="<?php the_permalink(); ?>"><?php echo get_the_title() ? the_title() : the_ID(); ?></a></h6>
                    <p class="text-small text-muted line-height-sm mb-0"><?php echo wp_trim_words( get_the_excerpt(), 9, '' );?></p>
                  </div>
                </div>
            <?php endwhile; ?>

            <?php echo $args['after_widget']; ?>
            <?php
            // Reset the global $the_post as this query will have stomped on it
            wp_reset_postdata();
            endif;
        }
}
function juliette_recent_widget_registration() {
  unregister_widget('WP_Widget_Recent_Posts');
  register_widget('Juliette_Recent_Posts_Widget');
}
add_action('widgets_init', 'juliette_recent_widget_registration');



/* comment form */

function theme_comment($comment, $args, $depth)
{
    $GLOBALS['comment'] = $comment; ?>

<ul class="list-unstyled comments" id="comment-<?php comment_ID() ?>">

    <?php
if ($comment->comment_approved == '0') : ?>
    <em>Your comment is awaiting moderation.</em>
    <?php endif; ?>

    <?php edit_comment_link(__('Edit Comment', 'juliette-wp'), '<span class="edit-comment-link">', '</span>'); ?>

           <li>
             <div class="media mb-4">
               <?php echo get_avatar('$comment', 60, '', '', ['class' => 'rounded-circle shadow-sm img-fluid']); ?>
               <div class="media-body ml-3">
                 <p class="small mb-0 text-primary"><?php comment_date(); ?></p>
                 <h5><?php comment_author(); ?></h5>
                 <p class="text-muted text-small mb-2"><?php comment_text(); ?></p>
                 <!-- <a class="reset-anchor text-small" href="#"><i class="fas fa-share mr-2 text-primary"></i><strong>Reply</strong></a> -->
                <i class="fas fa-share mr-2 text-primary"> <strong><?php comment_reply_link(array_merge($args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?></i></strong>
               </div>
             </div>
           </li>

</ul>

    <?php
}

function juliette_comment_form( $arg ) {
    // $arg contains all the comment form defaults
    // simply redefine one of the existing array keys to change the comment form
    // see http://codex.wordpress.org/Function_Reference/comment_form for a list
    // of array keys

    // add Foundation classes to the button class
    $arg['class_submit'] = 'btn btn-primary';

    // return the modified array
    return $arg;
}

// run the comment form defaults through the newly defined filter
add_filter( 'comment_form_defaults', 'juliette_comment_form' );
