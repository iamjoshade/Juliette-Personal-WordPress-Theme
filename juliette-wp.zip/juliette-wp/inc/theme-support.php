<?php
 /*
    @package Juliette
    displaying post category
 */
 function juliette_category_class($thelist){
   $categories = get_the_category();

   if ( !$categories || is_wp_error($categories) ) {
     return $thelist;
   }

   $output ='';
   foreach ( $categories as $category ) {
     $output .= '<li class="list-inline-item mr-2"><a class="category-link font-weight-normal" href="' . esc_url(get_category_link($category->term_id)) . '">' . $category->name . '</a></li>';
   }


   return $output;
 }
 add_filter( 'the_category', 'juliette_category_class');

 function juliette_class_the_tags($html){
     $postid = get_the_ID();
     $html = str_replace('<a','<a class="sidebar-tag-link"',$html);
     return $html;
 }
 add_filter('the_tags','juliette_class_the_tags',10,1);

/*

@package Juliette

	========================
		REMOVE GENERATOR VERSION NUMBER
	========================
*/

/* remove version string from js and css */
function juliette_remove_wp_version_strings( $src ) {

global $wp_version;
parse_str( parse_url($src, PHP_URL_QUERY), $query );
if ( !empty( $query['ver'] ) && $query['ver'] === $wp_version ) {
  $src = remove_query_arg( 'ver', $src );
}
return $src;

}
add_filter( 'script_loader_src', 'juliette_remove_wp_version_strings' );
add_filter( 'style_loader_src', 'juliette_remove_wp_version_strings' );

/* remove metatag generator from header */
function juliette_remove_meta_version() {
return '';
}
add_filter( 'the_generator', 'juliette_remove_meta_version' );



/* Recent Post Extention */
/**
 * Extend Recent Posts Widget
 *
 * Adds different formatting to the default WordPress Recent Posts Widget
 */

Class Juliette_Recent_Posts_Widget extends WP_Widget_Recent_Posts {

        function widget($args, $instance) {

                if ( ! isset( $args['widget_id'] ) ) {
                $args['widget_id'] = $this->id;
            }

            $title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Recent Posts', 'juliette-wp' );

            /** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
            $title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

            $number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 5;
            if ( ! $number )
                $number = 5;
            $show_date = isset( $instance['show_date'] ) ? $instance['show_date'] : false;

            /**
             * Filter the arguments for the Recent Posts widget.
             *
             * @since 3.4.0
             *
             * @see WP_Query::get_posts()
             *
             * @param array $args An array of arguments used to retrieve the recent posts.
             */
            $r = new WP_Query( apply_filters( 'widget_posts_args', array(
                'posts_per_page'      => $number,
                'no_found_rows'       => true,
                'post_status'         => 'publish',
                'ignore_sticky_posts' => true
            ) ) );

            if ($r->have_posts()) :
            ?>
            <?php echo $args['before_widget']; ?>
            <?php if ( $title ) {
                echo $args['before_title'] . $title . $args['after_title'];
            } ?>

            <?php while ( $r->have_posts() ) : $r->the_post();?>

                <div class="media mb-3">
                  <?php if(has_post_thumbnail()) : ?>
                    <a class="d-block" href="<?php the_permalink();?>">
                    <?php the_post_thumbnail('blog-post-recent-post', array('class' => 'img-fluid'));?>
                  </a>

                  <?php else:?>
                   <a class="d-block" href="<?php the_permalink();?>">
                   <img class="img-fluid" src="<?php echo esc_url( get_template_directory_uri());?>/assets/img/recent-blog-post-thumbnail.jpg" alt="<?php the_title();?>" width="70">
                  </a>
                <?php endif?>
                  <div class="media-body ml-3">
                    <h6> <a class="reset-anchor" href="<?php the_permalink(); ?>"><?php echo esc_html( get_the_title()) ? the_title() : the_ID(); ?></a></h6>
                    <p class="text-small text-muted line-height-sm mb-0"><?php echo esc_html(wp_trim_words( get_the_excerpt(), 9, '' ));?></p>
                  </div>
                </div>
            <?php endwhile; ?>

            <?php echo $args['after_widget']; ?>
            <?php
            // Reset the global $the_post as this query will have stomped on it
            wp_reset_postdata();
            endif;
        }
}
function juliette_recent_widget_registration() {
  unregister_widget('WP_Widget_Recent_Posts');
  register_widget('Juliette_Recent_Posts_Widget');
}
add_action('widgets_init', 'juliette_recent_widget_registration');


function juliette_comment_form( $arg ) {
    // $arg contains all the comment form defaults
    // simply redefine one of the existing array keys to change the comment form
    // see http://codex.wordpress.org/Function_Reference/comment_form for a list
    // of array keys

    // add Foundation classes to the button class
    $arg['class_submit'] = 'btn btn-primary';

    // return the modified array
    return $arg;
}

// run the comment form defaults through the newly defined filter
add_filter( 'comment_form_defaults', 'juliette_comment_form' );



//Custom code for blog post pagination
function juliette_number_pagination()
    {
        global $wp_query;
        $big = 9999999; // need an unlikely integer
        echo paginate_links(array(
         'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
         'format' => '?paged=%#%',
         'current' => max(1, get_query_var('paged')),
         'total' => $wp_query->max_num_pages));
    }



    function juliette_latest_sticky() { 
 
      /* Get all sticky posts */
      $sticky = get_option( 'sticky_posts' );
       
      /* Sort the stickies with the newest ones at the top */
      rsort( $sticky );
       
      /* Get the 5 newest stickies (change 5 for a different number) */
      $sticky = array_slice( $sticky, 0, 1 );
      if (!empty($sticky)) : 
      /* Query sticky posts */
      $the_query = new WP_Query( array( 'post__in' => $sticky, 'ignore_sticky_posts' => 1, 'posts_per_page' => 1  ) );
      // The Loop
      if ( $the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
              
  <section class="bg-white pb-5">
    <div class="container-fluid px-0 pnb-4">
        <div id="post-<?php the_ID();?>" <?php post_class('row align-items-center');?>>
            <div class="col-lg-12">
                <div class="post-thumnail">
                    <?php if(has_post_thumbnail( )):?>
                    <?php the_post_thumbnail('blog-post-row', ['class' => 'img-fluid w-100']);?>
                    <?php else:?>
            <img src="<?php echo get_template_directory_uri()?>/assets/img/juliette-front-sticky-image.jpg" class="img-fluid" alt="<?php the_title();?>">
                    <?php endif;?>
                </div>
            </div>
            <div class="col-lg-6 mx-auto text-center">
                <ul class="list-inline">
                    <?php the_category();?>
                    <li class="list-inline-item mx-3"><a class="text-uppercase meta-link font-weight-normal"
                            href="<?php echo get_author_posts_url(get_the_author_meta('ID'));?>"><?php the_author();?></a>
                    </li>
                    <li class="list-inline-item mx-3"><span class="text-uppercase meta-link font-weight-normal"><?php echo esc_html( get_the_date() ); ?></span>
                    </li>
                </ul>
                <h1 class="mb-4"> <a class="reset-anchor"
                        href="<?php the_permalink()?>"><?php echo get_the_title();?></a></h1>
                <p class="text-muted"><?php the_excerpt();?></p>
                <a class="btn btn-link p-0 read-more-btn"
                    href="<?php the_permalink();?>"><span><?php _e('Read More', 'juliette-wp')?></span><i
                        class="fas fa-long-arrow-alt-right"></i></a>
            </div>
        </div>
    </div>
</section>
              
               
          <?php endwhile; endif; wp_reset_postdata();?>
             <?php endif;?>       
         
    <?php }



           

        
           
        
           
     
      