<?php

function juliette_theme_setup(){

   add_theme_support('post-thumbnails');
   add_theme_support('title-tag');
   add_theme_support('custom-logo');
   add_theme_support( 'automatic-feed-links' );
   add_theme_support('html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption' ) );
   add_theme_support( 'custom-background' );
   add_theme_support( 'custom-header' );
   add_editor_style('editor-style.css');

   register_nav_menu( 'primary', __('Primary Menu', 'juliette-wp' ));

   if ( ! isset( $content_width ) ) {
        $content_width = 900;
    }

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
    }

    add_image_size( 'blog-post-thumbnail', 397, 264, array( 'center', 'center' ) );
    add_image_size( 'blog-post-main', 1110, 553, array( 'center', 'center' ) );
    add_image_size( 'blog-post-row', 1440, 502, array( 'center', 'center' ) );
    add_image_size( 'blog-post-recent-post', 70, 63, array( 'center', 'center' ) );

}
