<?php

function juliette_theme_setup(){

   add_theme_support('post-thumbnails');
   add_theme_support('title-tag');
   add_theme_support('custom-logo');
   add_theme_support( 'automatic-feed-links' );
   add_theme_support('html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption' ) );

   register_nav_menu( 'primary', __('Primary Menu', 'juliette-wp' ));

   if ( ! isset( $content_width ) ) {
        $content_width = 900;
    }

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
    }

    add_image_size( 'blog-post-thumbnail', 397, 264, array( 'center', 'center' ) );
    add_image_size( 'blog-post-main', 1110, 553, array( 'center', 'center' ) );
    add_image_size( 'blog-post-row', 1440, 502, array( 'center', 'center' ) );
    add_image_size( 'blog-post-recent-post', 70, 63, array( 'center', 'center' ) );

    $text_domain = 'juliette-wp';
    load_theme_textdomain( $text_domain, get_stylesheet_directory() . '/languages' );
    load_theme_textdomain( $text_domain, get_template_directory() . '/languages' );

}
