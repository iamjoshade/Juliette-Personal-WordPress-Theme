<?php

/*
@package Juliette

Enqueue all necessary files for the theme.

*/


function juliette_load_scripts(){

  wp_enqueue_script('bootstrap-js', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), '4.4.1', true);
  wp_enqueue_script('lihtbox', get_template_directory_uri() . '/assets/lightbox2/js/lightbox.min.js', array('jquery'), '2.11.1', true);
  wp_enqueue_script('custom-js', get_template_directory_uri() . '/assets/js/custom.js', array('jquery'), '1.0', true);


  wp_enqueue_style('bootstrap-css', get_template_directory_uri() . '/assets/css/bootstrap.min.css');
  wp_enqueue_style('lightbox', get_template_directory_uri() . '/assets/lightbox2/css/lightbox.min.css');
    wp_enqueue_style('fontawesome', 'https://use.fontawesome.com/releases/v5.7.1/css/all.css');
  wp_enqueue_style('google-font', 'https://fonts.googleapis.com/css?family=Open+Sans:300,400,700&amp;display=swap');
  wp_enqueue_style('google-font-2', 'https://fonts.googleapis.com/css?family=Satisfy&amp;display=swap');
  wp_enqueue_style('main-style', get_template_directory_uri() . '/style.css');
}



function juliette_admin_enqueue(){

    $currentscreen = get_current_screen();
    if( $currentscreen->id == 'widgets' ){
        wp_enqueue_media();
    	wp_enqueue_script( 'juliette-widget', get_template_directory_uri() . '/assets/js/widget.js', array( 'jquery'), '20160714', true );
    	 $array = array(
	        'remove'     => esc_html__('Remove','juliette-wp'),
	        'uploadimage'     => esc_html__('Author Image','juliette-wp'),
	    );
	    wp_localize_script( 'juliette-widget', 'juliette_widget_date', $array );
     }

}
add_action('admin_enqueue_scripts','juliette_admin_enqueue');
