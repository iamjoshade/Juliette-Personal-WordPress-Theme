<?php

/*
@package Juliette

Enqueue all necessary files for the theme.

*/


function juliette_load_scripts(){


  wp_deregister_script( 'jquery' );
  wp_enqueue_script('jquery', get_template_directory_uri() . '/assets/js/jquery.min.js', array(), '3.4.1', true);

  wp_enqueue_script('bootstrap-js', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), '4.4.1', true);
  wp_enqueue_script('lihtbox', get_template_directory_uri() . '/assets/lightbox2/js/lightbox.min.js', array('jquery'), '2.11.1', true);
  wp_enqueue_script('custom-js', get_template_directory_uri() . '/assets/js/custom.js', array('jquery'), '1.0', true);


  wp_enqueue_style('bootstrap-css', get_template_directory_uri() . '/assets/css/bootstrap.min.css');
  wp_enqueue_style('lightbox', get_template_directory_uri() . '/assets/lightbox2/css/lightbox.min.css');
    wp_enqueue_style('fontawesome', 'https://use.fontawesome.com/releases/v5.7.1/css/all.css');
  wp_enqueue_style('google-font', 'https://fonts.googleapis.com/css?family=Open+Sans:300,400,700&amp;display=swap');
  wp_enqueue_style('google-font-2', 'https://fonts.googleapis.com/css?family=Satisfy&amp;display=swap');
  wp_enqueue_style('main-style', get_template_directory_uri() . '/style.css');
}
