<?php


/*
	
@package sunsettheme
	
	========================
		THEME CUSTOM POST TYPES
	========================
*/



/* CONTACT CPT */
function juliette_quote_custom_post_type() {
	$labels = array(
		'name' 				=> 'Quotes',
		'singular_name' 	=> 'Quote',
		'menu_name'			=> 'Quotes',
		'name_admin_bar'	=> 'Quote'
	);
	
	$args = array(
		'labels'			=> $labels,
		'show_ui'			=> true,
		'show_in_menu'		=> true,
		'capability_type'	=> 'post',
		'hierarchical'		=> false,
		'menu_position'		=> 26,
		'menu_icon'			=> 'dashicons-format-quote',
		'supports'			=> array( 'title', 'editor', 'author' )
	);
	
	register_post_type( 'juliette-quote', $args );
	
}
add_action( 'init', 'juliette_quote_custom_post_type' );
















