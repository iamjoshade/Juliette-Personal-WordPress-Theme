<?php
/**
 * @package Juliette WP
 */

add_action('widgets_init', 'juliette_author_register');

function juliette_author_register() {
    register_widget('Juliette_Author_Widget');
}

class Juliette_Author_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
                'Juliette_Author_Widget', esc_html__(' Juliette Author Box', 'juliette-wp'), array(
                'description' => esc_html__('Show Author Profile', 'juliette-wp')
                )
        );
    }

    /**
     * Helper function that holds widget fields
     * Array is used in update and form functions
     */
    private function widget_fields() {

        $fields = array(
            'juliette_author_name' => array(
                'juliette_widgets_name' => 'juliette_author_name',
                'juliette_widgets_title' => esc_html__('Author Name', 'juliette-wp'),
                'juliette_widgets_field_type' => 'text',
            ),
            'juliette_author_desc' => array(
                'juliette_widgets_name' => 'juliette_author_desc',
                'juliette_widgets_title' => esc_html__('Author Words', 'juliette-wp'),
                'juliette_widgets_field_type' => 'textarea',
            ),
            'juliette_author_image' => array(
                'juliette_widgets_name' => 'juliette_author_image',
                'juliette_widgets_title' => esc_html__('Author Image', 'juliette-wp'),
                'juliette_widgets_field_type' => 'upload',
            ),
            'juliette_author_facebook' => array(
                'juliette_widgets_name' => 'juliette_author_facebook',
                'juliette_widgets_title' => esc_html__('Facebook Link', 'juliette-wp'),
                'juliette_widgets_field_type' => 'text',
            ),
            'juliette_author_twitter' => array(
                'juliette_widgets_name' => 'juliette_author_twitter',
                'juliette_widgets_title' => esc_html__('Twitter Link', 'juliette-wp'),
                'juliette_widgets_field_type' => 'text',
            ),
            'juliette_author_youtube' => array(
                'juliette_widgets_name' => 'juliette_author_youtube',
                'juliette_widgets_title' => esc_html__('Youtube Link', 'juliette-wp'),
                'juliette_widgets_field_type' => 'text',
            ),
            'juliette_author_instagram' => array(
                'juliette_widgets_name' => 'juliette_author_instagram',
                'juliette_widgets_title' => esc_html__('Instagram Link', 'juliette-wp'),
                'juliette_widgets_field_type' => 'text',
            ),
        );

        return $fields;
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget($args, $instance) {
        extract($args);
        
        $juliette_author_name = apply_filters( 'widget_title', empty( $instance['juliette_author_name'] ) ? '' : $instance['juliette_author_name'], $instance, $this->id_base );       
        $juliette_author_desc = isset( $instance['juliette_author_desc'] ) ? $instance['juliette_author_desc'] : '' ;
        $juliette_author_image = isset( $instance['juliette_author_image'] ) ? $instance['juliette_author_image'] : '' ;
        $juliette_author_facebook = isset( $instance['juliette_author_facebook'] ) ? $instance['juliette_author_facebook'] : '' ;
        $juliette_author_twitter = isset( $instance['juliette_author_twitter'] ) ? $instance['juliette_author_twitter'] : '' ;
        $juliette_author_youtube = isset( $instance['juliette_author_youtube'] ) ? $instance['juliette_author_youtube'] : '' ;
        $juliette_author_instagram = isset( $instance['juliette_author_facebook'] ) ? $instance['juliette_author_instagram'] : '' ;
        
        echo $before_widget;
        ?>
             <div class="card rounded-0 border-0 bg-light mb-4 py-lg-4">
              <div class="card-body text-center">
                <?php if($juliette_author_name){ ?><h2 class="h3 mb-3"><?php echo esc_html($juliette_author_name); ?></h2> <?php } ?>

                <?php  if( $juliette_author_image ){ ?>
                <img class="rounded-circle mb-3" src="<?php echo esc_url( $juliette_author_image ); ?>" alt="<?php echo esc_html($juliette_author_name); ?>" width="100">
                <?php } ?>

            <?php if($juliette_author_desc){ ?><p class="text-small text-muted"><?php echo esc_html($juliette_author_desc); ?></p> <?php } ?>
                <ul class="list-inline small mb-0 text-dark">
                     <?php if( $juliette_author_facebook ){ ?>
                <li class="list-inline-item"><a class="reset-anchor" target="_blank" href="<?php echo esc_url( $juliette_author_facebook ); ?>">
                    <i class="fab fa-facebook-f"></i></a></li>
                   <?php } ?>

                   <?php if( $juliette_author_twitter ){ ?>
                  <li class="list-inline-item"><a class="reset-anchor" target="_blank" href="<?php echo esc_url( $juliette_author_twitter ); ?>"><i class="fab fa-twitter"></i></a></li>
                   <?php } ?>

                   <?php if( $juliette_author_instagram ){ ?>
                  <li class="list-inline-item"><a class="reset-anchor" target="_blank" href="<?php echo esc_url( $juliette_author_instagram ); ?>"><i class="fab fa-instagram"></i></a></li>
                   <?php } ?>
                  
                  <?php if( $juliette_author_youtube ){ ?>
                  <li class="list-inline-item"><a class="reset-anchor" target="_blank" href="<?php echo esc_url( $juliette_author_youtube ); ?>"><i class="fab fa-youtube"></i></a></li>
                  <?php } ?>
                </ul>
              </div>
            </div>


        <?php
        echo $after_widget;
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param   array   $new_instance   Values just sent to be saved.
     * @param   array   $old_instance   Previously saved values from database.
     *
     * @uses    juliette_widgets_updated_field_value()        defined in widget-fields.php
     *
     * @return  array Updated safe values to be saved.
     */
    public function update($new_instance, $old_instance) {
        $instance = $old_instance;

        $widget_fields = $this->widget_fields();

        // Loop through fields
        foreach ($widget_fields as $widget_field) {

            extract($widget_field);

            // Use helper function to get updated field values
            $instance[$juliette_widgets_name] = juliette_widgets_updated_field_value($widget_field, $new_instance[$juliette_widgets_name]);
        }

        return $instance;
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param   array $instance Previously saved values from database.
     *
     * @uses    juliette_widgets_show_widget_field()      defined in widget-fields.php
     */
    public function form($instance) {
        $widget_fields = $this->widget_fields();

        // Loop through fields
        foreach ($widget_fields as $widget_field) {

            // Make array elements available as variables
            extract($widget_field);
            $juliette_widgets_field_value = !empty($instance[$juliette_widgets_name]) ? esc_attr($instance[$juliette_widgets_name]) : '';
            juliette_widgets_show_widget_field($this, $widget_field, $juliette_widgets_field_value);
        }
    }

}

