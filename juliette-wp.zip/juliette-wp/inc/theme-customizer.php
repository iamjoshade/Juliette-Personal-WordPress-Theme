<?php 

function juliette_customize_register($wp_customize){

    $wp_customize->add_panel('juliette', [
        'title'             => __('Juliette WP Theme Settings', 'juliette-wp'),
        'description'       =>  '<p>Juliette WP Theme Settings</p>',
        'priority'          => 160
    ]);

    juliette_social_customizer( $wp_customize );
    juliette_featured_category($wp_customize);
    juliette_newsletter($wp_customize);
    
}
