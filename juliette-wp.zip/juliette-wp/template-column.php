<?php get_header();
 

 /*
 
@package Juliette

Custom Template for List Blog Page

Template Name: Blog Column Template
 */
?>
 <section class="py-5">
     <div class="container py-4">
       <div class="row">
         <!-- Blog listing-->
         <div class="col-lg-9 mb-5 mb-lg-0">
           <div class="row">
           <?php $paged = ( get_query_var('paged') ) ? get_query_var( 'paged' ) : 1;
            query_posts( 
                array ( 
                    'post_type' => 'post', 
                    'paged' => $paged ) 
                );      
                  while(have_posts()) :the_post();?>

                <?php get_template_part( 'template-parts/content-list');?>
              
              <?php endwhile;?>
                <nav aria-label="Page navigation example">
                <ul class="pagination">
                <?php juliette_number_pagination();?>
                </ul>
              </nav>
           </div>
          
         </div>
        <?php get_sidebar();?>
       </div>
     </div>
   </section>
<?php get_footer();?>