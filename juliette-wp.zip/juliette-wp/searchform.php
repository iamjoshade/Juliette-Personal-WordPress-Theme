<?php $unique_id = esc_attr(uniqid());?>
<form action="<?php echo esc_url(home_url('/'));?>" method="get" role="search" class="search-form">
	<div class="form-group">
		<input type="text" class="form-control" placeholder="<?php esc_attr_e('Type a keyword and hit enter', 'juliette-wp')?>"  name='s' id="<?php echo $unique_id?>">
	</div>
  <div class="form-group">
    <button class="btn btn-primary" type="submit"><?php esc_html_e('Search', 'juliette-wp');?></button>
  </div>
</form>
