<?php get_header();
/*
@package Juliette

Custom Template for home page

Template Name: Blog Home
*/

?>


<?php
// Get IDs of sticky posts
$sticky = get_option('sticky_posts');

rsort( $sticky );

$sticky = array_slice( $sticky, 0, 1 );
// first loop to display only my single, 
// MOST RECENT sticky post
$most_recent_sticky_post = new WP_Query( array( 
    // Only sticky posts
    'post__in' => $sticky, 
    // Treat them as sticky posts
    'ignore_sticky_posts' => 1, 
    // Get only the one most recent
) );
while ( $most_recent_sticky_post->have_posts() ) : $most_recent_sticky_post->the_post(); ?>

<section class="bg-white pb-5">
    <div class="container-fluid px-0 pnb-4">
        <div id="post-<?php the_ID();?>" <?php post_class('row align-items-center');?>>
            <div class="col-lg-12">
                <div class="post-thumnail">
                    <?php if(has_post_thumbnail( )):?>
                    <?php the_post_thumbnail('blog-post-row', ['class' => 'img-fluid w-100']);?>
                    <?php else:?>
            <img src="<?php echo esc_html( get_template_directory_uri())?>/assets/img/juliette-front-sticky-image.jpg" class="img-fluid" alt="<?php the_title();?>">
                    <?php endif;?>
                </div>
            </div>
            <div class="col-lg-6 mx-auto text-center">
                <ul class="list-inline">
                    <?php the_category();?>
                    <li class="list-inline-item mx-3"><a class="text-uppercase meta-link font-weight-normal"
                            href="<?php echo get_author_posts_url(get_the_author_meta('ID'));?>"><?php the_author();?></a>
                    </li>
                    <li class="list-inline-item mx-3"><span class="text-uppercase meta-link font-weight-normal"><?php echo esc_html( get_the_date() ); ?></span>
                    </li>
                </ul>
                <h1 class="mb-4"> <a class="reset-anchor"
                        href="<?php the_permalink()?>"><?php echo get_the_title();?></a></h1>
                <p class="text-muted"><?php the_excerpt();?></p>
                <a class="btn btn-link p-0 read-more-btn"
                    href="<?php the_permalink();?>"><span><?php _e('Read More', 'juliette-wp')?></span><i
                        class="fas fa-long-arrow-alt-right"></i></a>
            </div>
        </div>
    </div>
</section>

<?php endwhile; wp_reset_postdata(); ?>

<!-- Home listing-->
<section class="py-5">
    <div class="container pb-4">
        <div class="row">
            <div class="col-lg-9 mb-5 mb-lg-0">
<?php query_posts( array( 
    // exclude all sticky posts
'post__not_in' => get_option( 'sticky_posts' ) ) );  
if (have_posts()) : while (have_posts()) : the_post(); ?>
    <div class="row align-items-center mb-5 juliette-post-container">
        <div class="col-lg-6">
            <a class="d-block mb-4" href="<?php the_permalink();?>">
                <?php if(has_post_thumbnail()): ?>
                <?php the_post_thumbnail( 'blog-post-thumbnail', ['class' => 'img-fluid'])?>
                <?php else:?>
            <img src="<?php echo esc_html(get_template_directory_uri())?>/assets/img/juliette-thumbnail-image.jpg" class="img-fluid" alt="<?php the_title();?>">
              <?php endif;?>
              
            </a>
        </div>
        <div class="col-lg-6">
            <ul class="list-inline">
                <?php the_category();?>
                <li class="list-inline-item mx-2"><a class="text-uppercase meta-link font-weight-normal"
                        href="<?php echo get_author_posts_url(get_the_author_meta('ID'));?>"><?php the_author();?></a>
                </li>
                <li class="list-inline-item mx-2"><span class="text-uppercase meta-link font-weight-normal"
                        href="#"><?php echo esc_html( get_the_date() ); ?></span></li>
            </ul>
            <h2 class="h3 mb-4"> <a class="d-block reset-anchor"
                    href="<?php the_permalink();?>"><?php the_title();?></a></h2>
            <p class="text-muted"><?php the_excerpt();?></p><a class="btn btn-link p-0 read-more-btn"
                href="<?php the_permalink()?>"><span><?php esc_html_e('Read More', 'juliette-wp')?></span><i
                    class="fas fa-long-arrow-alt-right"></i></a>
        </div>
    </div>

  <?php endwhile; endif;  wp_reset_postdata(); ?>

  <div class="btn btn-primary read-more text-center">
    <a class="juliette-load-more" data-page="1" data-url="<?php echo admin_url('admin-ajax.php')?>">Load More Post</a>
 </div>

        </div>
        <?php get_sidebar();?>
    </div>
</div>
</section>


<?php get_footer();?>