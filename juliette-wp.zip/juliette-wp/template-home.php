<?php get_header();

/*
@package Juliette

Custom Template for home page

Template Name: Blog Home
*/

?>


<?php $args = array(
      'posts_per_page' => 1,
      'post_type'      => 'post',
      'order_by'       => 'ASC'
);?>



<?php $latest_post = new WP_Query($args); while($latest_post->have_posts()) : $latest_post->the_post(); ?>
<section class="bg-white pb-5">
  <div class="container-fluid px-0 pnb-4">
    <div class="row align-items-center">
      <div class="col-lg-12">
        <div class="post-thumnail">
          <?php if(has_post_thumbnail( )):?>
          <?php the_post_thumbnail('blog-post-row', ['class' => 'img-fluid w-100']);?>
        <?php endif;?>
        </div>
      </div>
      <div class="col-lg-6 mx-auto text-center">
        <ul class="list-inline">
            <?php the_category();?>
          <li class="list-inline-item mx-3"><a class="text-uppercase meta-link font-weight-normal" href="#"><?php the_author();?></a></li>
          <li class="list-inline-item mx-3"><span class="text-uppercase meta-link font-weight-normal"></span></li>
        </ul>
        <h1 class="mb-4"> <a class="reset-anchor" href="<?php the_permalink();?>"><?php the_title();?></a></h1>
        <p class="text-muted"><?php the_excerpt();?></p>
        <a class="btn btn-link p-0 read-more-btn" href="<?php the_permalink();?>"><span><?php _e('Read More', 'juliette-wp')?></span><i class="fas fa-long-arrow-alt-right"></i></a>
      </div>
    </div>
  </div>
</section>
<?php endwhile; wp_reset_postdata(); ?>



<!-- Top categories-->
<section class="pb-5">
  <div class="container pb-4">
    <div class="row mb-5 pb-4">

    <?php $categories = get_categories( array('hide_empty' => 0,'parent'  => 0) );
        $limit=3;
        $counter=0;
        foreach ($categories as $cat) :
        if($counter<$limit):?>

      <div class="col-lg-4 mb-4 mb-lg-0">
        <a class="category-block bg-center bg-cover" href="<?php echo get_category_link($cat->term_id); ?>">
          <span class="category-block-title"><?php echo $cat->cat_name; ?></span>
        </a></div>
      <?php endif; $counter++; endforeach; ?>
    </div>
   
  </div>
</section>


<!-- Home listing-->
<section class="pb-5">
  <div class="container pb-4">
    <div class="row">
      <div class="col-lg-9 mb-5 mb-lg-0">
        <?php $args = array(
              'posts_per_page' => 4,
              'post_type'      => 'post',
              'order_by'       => 'ASC',

        );?>

        <?php $featured_post = new WP_Query($args); while($featured_post->have_posts()) : $featured_post->the_post();?>
        <div class="row align-items-center mb-5">
          <div class="col-lg-6"><a class="d-block mb-4" href="<?php the_permalink();?>">
          <?php if(has_post_thumbnail()): ?>
              <?php the_post_thumbnail( 'blog-post-thumbnail', ['class' => 'img-fluid'])?>
          <?php endif;?>
          </a>
          </div>
          <div class="col-lg-6">
            <ul class="list-inline">
            <?php the_category();?>
              <li class="list-inline-item mx-2"><a class="text-uppercase meta-link font-weight-normal" href="<?php echo get_author_posts_url(get_the_author_meta('ID'));?>"><?php the_author();?></a></li>
              <li class="list-inline-item mx-2"><span class="text-uppercase meta-link font-weight-normal" href="#"><?php echo esc_html( get_the_date() ); ?></span></li>
            </ul>
            <h2 class="h3 mb-4"> <a class="d-block reset-anchor" href="<?php the_permalink();?>"><?php the_title();?></a></h2>
            <p class="text-muted"><?php the_excerpt();?></p><a class="btn btn-link p-0 read-more-btn" href="<?php the_permalink()?>"><span><?php _e('Read More', 'juliette-wp')?></span><i class="fas fa-long-arrow-alt-right"></i></a>
          </div>
        </div>
      <?php endwhile; wp_reset_postdata();?>

          
      <?php $args = array(
              'posts_per_page' => 1,
              'post_type'      => 'juliette-quote',
              'order_by'       => 'ASC'
        );?>

<?php $quote = new WP_Query($args); while($quote->have_posts()) : $quote->the_post();?>
        <blockquote class="blockquote bg-dark text-white p-4 p-lg-5 text-center mb-5">
          <p class="h4 mb-4"><?php the_content();?></p>
          <footer class="blockquote-footer">
            <cite class="text-white" title="Source Title">
            <?php
              $author = get_post_meta($post->ID, '_author_name_value_key', true);
             echo $author;
        ?>
            </cite>
          </footer>
        </blockquote>
  <?php endwhile; wp_reset_postdata();?>

      </div>
      <!-- Blog sidebar-->
      <?php get_sidebar();?>
    </div>
  </div>
</section>

<?php get_footer();?>
