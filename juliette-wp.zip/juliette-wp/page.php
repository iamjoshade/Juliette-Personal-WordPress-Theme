<?php

/*
@package Juliette
*/
get_header();?>


<section class="bg-white pb-5">
  <div class="container-fluid px-0 pnb-4">
  <?php while(have_posts()): the_post();?>
    <div class="row align-items-center">
      <div class="col-lg-12">
        <div class="post-thumnail">
          <?php if(has_post_thumbnail( )):?>
          <?php the_post_thumbnail('blog-post-row', ['class' => 'img-fluid w-100']);?>
        <?php endif;?>
        </div>
      </div>
      <div class="col-lg-6 mx-auto text-center">

        <h1 class=" mt-4 mb-4"> <a class="reset-anchor" href="<?php the_permalink();?>"><?php the_title();?></a></h1>
        <p class="text-muted"><?php the_content();?></p>
        
      </div>
    </div>
    <?php endwhile;?>

        <?php $defaults = array(
        'before'           => '<p class="text-center">' . __( 'Pages:', 'juliette-wp' ),
        'after'            => '</p>',
        ); wp_link_pages( $defaults ); wp_link_pages();?>

        <?php if(comments_open() || get_comments_number()){
            comments_template();
        }?>

  </div>
</section>



<?php get_footer();?>
