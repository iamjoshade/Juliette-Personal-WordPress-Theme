<?php get_header();
/*
@package Juliette
*/

?>


<section class="py-5">
    <div class="container py-4">
      <div class="row">
        <!-- Blog listing-->
        <div class="col-lg-9 mb-5 mb-lg-0">
            <?php
                global $paged;
                $curpage = $paged ? $paged : 1;
                $args = array(
                      'post_type'      => 'post',
                      'order_by'       => 'ASC',
                      'paged'          => $paged
                );?>

                <?php $blog_post = new WP_Query($args); if($blog_post->have_posts()) : while($blog_post->have_posts()) : $blog_post->the_post();?>
            <div  id="post-<?php the_ID();?>" <?php post_class('row align-items-center mb-5');?>>
            <?php get_template_part( 'template-parts/content');?>
             </div>
          <?php endwhile; endif;?>
          <?php if ($blog_post->max_num_pages > 1) :?>
          <nav aria-label="Page navigation example">
              <ul class="pagination">
                <li class="page-item"><a class="page-link" href="<?php echo get_pagenum_link(($curpage-1 > 0 ? $curpage-1 : 1))?>">&laquo;</a></li>
                <?php for($i=1;$i<=$blog_post->max_num_pages;$i++):?>
                <li class="page-item <?php echo ($i === $curpage) ? 'active' : ''?>"><a class="page-link" href="<?php echo get_pagenum_link($i)?>"><?php echo $i;?></a></li>
                <?php endfor;?>
                <li class="page-item"><a class="page-link" href="<?php echo get_pagenum_link(($curpage+1 <= $blog_post->max_num_pages ? $curpage+1 : $blog_post->max_num_pages))?>">&raquo;</a></li>
              </ul>
            </nav>
          <?php endif; wp_reset_postdata();  ?>
        </div>
        <?php get_sidebar();?>
      </div>
    </div>
  </section>



<?php get_footer();?>
