<?php get_header();
/*
@package Juliette
*/

?>


<section class="py-5">
    <div class="container py-4">
      <div class="row">
        <!-- Blog listing-->
        <div class="col-lg-9 mb-5 mb-lg-0">
            

                <?php if(have_posts()) : while(have_posts()) : the_post();?>
            <div  id="post-<?php the_ID();?>" <?php post_class('row align-items-center mb-5');?>>
            <?php get_template_part( 'template-parts/content');?>
             </div>
          <?php endwhile; endif;?>
          <nav aria-label="Page navigation example">
              <ul class="pagination">
               <?php juliette_number_pagination();?>
              </ul>
            </nav>

        </div>
        <?php get_sidebar();?>
      </div>
    </div>
  </section>



<?php get_footer();?>
