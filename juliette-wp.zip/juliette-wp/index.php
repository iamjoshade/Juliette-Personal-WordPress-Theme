<?php get_header();
/*
@package Juliette
*/

?>

<?php juliette_latest_sticky();?>

<?php echo featured_category(); ?>

<section class="py-5">
    <div class="container py-4">
      <div class="row">
        <!-- Blog listing-->
        <div class="col-lg-9 mb-5 mb-lg-0">
                <?php  $sticky = get_option( 'sticky_posts' ); $the_query = new WP_Query( array( 'post__not_in' => $sticky) );
                 if($the_query->have_posts()) : while($the_query->have_posts()) : $the_query->the_post();?>
            <div id="post-<?php the_ID();?>" <?php post_class('row align-items-center mb-5');?>>
              <?php get_template_part( 'template-parts/content');?>
             </div>
          <?php endwhile; endif; wp_reset_postdata();?>
          <nav aria-label="Page navigation example">
              <ul class="pagination">
               <?php juliette_number_pagination();?>
              </ul>
            </nav>
        </div>
        <?php get_sidebar();?>
      </div>
    </div>
  </section>



<?php get_footer();?>
