function juliette_admin_enqueue(){

$currentscreen = get_current_screen();
if( $currentscreen->id == 'widgets' ){
    wp_enqueue_media();
    wp_enqueue_script( 'juliette-widget', get_template_directory_uri() . '/assets/js/widget.js', array( 'jquery'), '1.0', true );
     $array = array(
        'remove'     => esc_html__('Remove','juliette-wp'),
        'uploadimage'     => esc_html__('Author Image','juliette-wp'),
    );
    wp_localize_script( 'juliette-widget', 'juliette_widget_date', $array );
 }

}
add_action('admin_enqueue_scripts','juliette_admin_enqueue');




<p class="has-text-align-center"><a class="btn btn-primary" href="https://www.dropbox.com/s/5n742rf7cdzl71i/Author-widget.zip?dl=1" target="_blank" rel="noreferrer noopener">Download Author Widget codes</a></p>