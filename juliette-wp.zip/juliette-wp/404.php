<?php get_header();

/*
@package Juliette
404 page
*/
?>


<?php get_header();?>

<section class="py-5">
    <div class="container py-4">
      <div class="row">
        <!-- Blog listing-->
        <div class="col-lg-9 mb-5 mb-lg-0">
            <div class="row align-items-center mb-5">
            <h4><?php _e("Ooopps! The Page you were looking for, couldn't be found.", 'juliette-wp')?></h4><br/>            
             </div>
             <p><a class="btn btn-primary" href="<?php echo esc_url(home_url('/')); ?>"><?php _e('Back to home Page', 'juliette-wp');?></a></p>
        </div>
        <?php get_sidebar();?>
      </div>
    </div>
  </section>

<?php get_footer();?>





<?php get_footer();?>