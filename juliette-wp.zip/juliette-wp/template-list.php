<?php get_header();


 /*
@package Juliette

Custom Template for List Blog Page

Template Name: Blog Column Template
 */
?>

 <section class="py-5">
     <div class="container py-4">
       <div class="row">
         <!-- Blog listing-->
         <div class="col-lg-9 mb-5 mb-lg-0">
           <div class="row">
                <?php
                global $paged;
                $curpage = $paged ? $paged : 1;
                $args = array(
                      
                      'post_type'      => 'post',
                      'order_by'       => 'ASC',
                      'paged'          => $paged
                );?>

                <?php $list_post = new WP_Query($args); if($list_post->have_posts()) : while($list_post->have_posts()) : $list_post->the_post();?>

                <?php get_template_part( 'template-parts/content-list');?>
              <?php endwhile;?>
          
           </div>
            <?php if ($list_post->max_num_pages > 1) :?>
          <nav aria-label="Page navigation example">
              <ul class="pagination">
                <li class="page-item"><a class="page-link" href="<?php echo get_pagenum_link(($curpage-1 > 0 ? $curpage-1 : 1))?>">&laquo;</a></li>
                <?php for($i=1;$i<=$list_post->max_num_pages;$i++):?>
                <li class="page-item <?php echo ($i === $curpage) ? 'active' : ''?>"><a class="page-link" href="<?php echo get_pagenum_link($i)?>"><?php echo $i;?></a></li>
                <?php endfor;?>
                <li class="page-item"><a class="page-link" href="<?php echo get_pagenum_link(($curpage+1 <= $list_post->max_num_pages ? $curpage+1 : $list_post->max_num_pages))?>">&raquo;</a></li>
              </ul>
            </nav>
          <?php endif; wp_reset_postdata();  endif;?>
          
          
        

         </div>
        <?php get_sidebar();?>
       </div>
     </div>
   </section>


<?php get_footer();?>
