
<?php get_header();

/*
@package Juliette
*/


?>


<section class="py-5">
     <div class="container py-4">
       <?php while(have_posts()): the_post();?>
      <?php get_template_part('template-parts/content-single');?>
     <?php endwhile;?>
     </div>
   </section>

<?php get_footer();?>
