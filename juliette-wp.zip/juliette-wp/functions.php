<?php

include (get_template_directory() . '/inc/enqueue.php');
include (get_template_directory() . '/inc/functions-front.php');
include (get_template_directory() . '/inc/theme-support.php');
include (get_template_directory() . '/inc/widgets.php');
include (get_template_directory()) . '/inc/class-wp-bootstrap-navwalker.php';

/**
 * Customizer additions.
 */
require_once get_template_directory() . '/inc/customizer/social.php';



add_action( 'wp_enqueue_scripts', 'juliette_load_scripts' );
add_action('after_setup_theme', 'juliette_theme_setup');
add_action('widgets_init', 'juliette_theme_widgets');
