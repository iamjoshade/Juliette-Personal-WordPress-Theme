<!DOCTYPE html>
<html <?php language_attributes(); ?>>
  <head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php wp_head();?>
  </head>
  <body <?php body_class(); ?>>
    <?php wp_body_open(); ?>
    <!-- navbar-->
    <header class="header">
      <nav class="navbar navbar-expand-lg navbar-light py-4 index-forward bg-white">
        <div class="container d-flex justify-content-center justify-content-lg-between align-items-center">
          <ul class="list-inline small mb-0 text-dark d-none d-lg-block">       
            <li class="list-inline-item"><a class="reset-anchor" href="<?php echo esc_url(get_theme_mod('set_facebook' ));?>"><i class="fab fa-facebook-f"></i></a></li>
             <li class="list-inline-item"><a class="reset-anchor" href="<?php echo esc_url( get_theme_mod('set_twitter'));?>"><i class="fab fa-twitter"></i></a></li>
             <li class="list-inline-item"><a class="reset-anchor" href="<?php echo esc_url( get_theme_mod('set_instagram'));?>"><i class="fab fa-instagram"></i></a></li>
             <li class="list-inline-item"><a class="reset-anchor" href="<?php echo esc_url (get_theme_mod('set_linkedin'));?>"><i class="fab fa-linkedin"></i></a></li>
             <li class="list-inline-item"><a class="reset-anchor" href="<?php echo esc_url(get_theme_mod('set_youtube'));?>"><i class="fab fa-youtube"></i></a></li>
          </ul>

          <?php if(has_custom_logo()):?>
               <?php the_custom_logo()?>
           <?php else:?>
           <a class="navbar-brand" href="<?php echo esc_url(home_url('/'));?>"><h1><?php bloginfo('title');?></h1></a>
           <?php endif;?>
          
            <a class="reset-anchor text-small mb-0 h6 d-none d-lg-block" href="mailto:<?php echo esc_html(get_theme_mod('set_email'));?>"><i class="fa fa-envelope mr-2 text-primary"></i><?php echo esc_html(get_theme_mod('set_email'));?></a>
         
        </div>
      </nav>
      <nav class="navbar navbar-expand-lg navbar-light border-top border-bottom border-light">
        <div class="container">
          <ul class="list-inline small mb-0 text-dark d-block d-lg-none">
            <li class="list-inline-item"><a class="reset-anchor" href="<?php echo esc_url(get_theme_mod('set_facebook' ));?>"><i class="fab fa-facebook-f"></i></a></li>
             <li class="list-inline-item"><a class="reset-anchor" href="<?php echo esc_url( get_theme_mod('set_twitter'));?>"><i class="fab fa-twitter"></i></a></li>
             <li class="list-inline-item"><a class="reset-anchor" href="<?php echo esc_url( get_theme_mod('set_instagram'));?>"><i class="fab fa-instagram"></i></a></li>
             <li class="list-inline-item"><a class="reset-anchor" href="<?php echo esc_url (get_theme_mod('set_linkedin'));?>"><i class="fab fa-linkedin"></i></a></li>
             <li class="list-inline-item"><a class="reset-anchor" href="<?php echo esc_url(get_theme_mod('set_youtube'));?>"><i class="fab fa-youtube"></i></a></li>
          </ul>
          <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span></span><span></span><span></span></button>
                <?php
                      wp_nav_menu( $args = array(
                        'theme_location'    => 'primary',
                        'depth'             => 2,
                        'container_class'   => 'collapse navbar-collapse',
                        'container_id'      => 'navbarSupportedContent',
                        'menu_class'        => 'navbar-nav mx-auto',
                        'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
				        'walker'            => new WP_Bootstrap_Navwalker(),

                      ) );

                ?>

        </div>
      </nav>
    </header>
