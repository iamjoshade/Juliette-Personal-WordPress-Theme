<div class="col-lg-3">
  <div class="card rounded-0 border-0 mb-4 py-lg-4">
    <?php if(is_active_sidebar('juliette_sidebar')){
                dynamic_sidebar('juliette_sidebar');
            }?>
  </div>
</div>
