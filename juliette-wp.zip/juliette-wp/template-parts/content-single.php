<div class="row text-center">
  <div class="col-lg-8 mx-auto d-inline-block mb-4">
    <?php the_category();?>
    <h1 class="mt-4"><?php the_title();?></h1>
    <p><?php the_excerpt();?></p>
    <ul class="list-inline mb-5">
      <li class="list-inline-item mx-2"><a class="text-uppercase text-muted reset-anchor" href="<?php echo get_author_posts_url(get_the_author_meta('ID') );?>"><?php _e('BY', 'juliette-wp')?> <?php the_author();?></a></li>
      <li class="list-inline-item mx-2"><span class="text-uppercase text-muted reset-anchor"><?php echo get_the_date();?></span></li>
    </ul>
  </div>
</div>
<?php if( has_post_thumbnail()): ?>
      <?php the_post_thumbnail('blog-post-thumbnail', ['class' => 'img-fluid w-100 mb-5'] );?>
      <?php else:?>
        <img src="<?php echo get_template_directory_uri()?>/assets/img/juliette-single-post-image.jpg" class="img-fluid mb-5" alt="<?php the_title();?>">
      <?php endif;?>
<div class="row">
  <div <?php post_class('col-lg-9'); ?> id="post-<?php the_ID(); ?>">
    
   <?php the_content();?>
    <!-- Post tags-->
    <?php if(has_tag()):?>
    <div class="d-flex align-items-center flex-column flex-sm-row mb-4 p-4 bg-light">
      <h3 class="h4 mb-3 mb-sm-0"><?php _e('Tags', 'juliette-wp')?></h3>
      <ul class="list-inline mb-0 ml-0 ml-sm-3">
        <li class="list-inline-item my-1 mr-2">  <?php the_tags('', ' ');?></li>
      </ul>
    </div>
  <?php endif;?>
  <?php
        $title = get_the_title();
        $permalink = get_permalink();
        $twitter = 'https://twitter.com/intent/tweet?text=Hey! Read this: '.$title.'&amp;url='.$permalink.'';
        $facebook = 'https://www.facebook.com/sharer/sharer.php?u='.$permalink;
  ?>
    <!-- Post share-->
    <div class="d-flex align-items-center flex-column flex-sm-row mb-5 p-4 bg-light">
      <h3 class="h4 mb-3 mb-sm-0">Share this post</h3>
      <ul class="list-inline mb-0 ml-0 ml-sm-3">
        <li class="list-inline-item mr-1 my-1"><a class="social-link-share facebook" href="<?php echo esc_url ($facebook);?>" target="_blank"><i class="fab fa-facebook-f mr-2"></i>Share</a></li>
        <li class="list-inline-item mr-1 my-1"><a class="social-link-share twitter" href="<?php echo esc_url( $twitter);?>" target="_blank"><i class="fab fa-twitter mr-2"></i>Tweet</a></li>
      </ul>
    </div>
    <!-- Post comments-->
    <?php if(comments_open() || get_comments_number()){
                comments_template();
    }?>

  </div>

<?php get_sidebar();?>
</div>
