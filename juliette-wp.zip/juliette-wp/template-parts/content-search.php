<div class="col-lg-6">
  <a class="d-block mb-4" href="<?php the_permalink();?>">
  <?php the_post_thumbnail('blog-post-thumbnail', ['class' => 'img-fluid w-100'] );?>
   </a>
</div>
<div class="col-lg-6">
  <ul class="list-inline">
    <?php the_category();?>
    <li class="list-inline-item mx-2"><a class="text-uppercase meta-link font-weight-normal" href="<?php echo get_author_posts_url(get_the_author_meta('ID'));?>"><?php the_author();?></a></li>
    <li class="list-inline-item mx-2"><span class="text-uppercase meta-link font-weight-normal"><?php echo esc_html( get_the_date() ); ?></span></li>
  </ul>
  <h2 class="h3 mb-4"> <a class="d-block reset-anchor" href="<?php the_permalink();?>"><?php the_title();?></a></h2>
  <p class="text-muted"><?php the_excerpt();?></p><a class="btn btn-link p-0 read-more-btn" href="<?php the_permalink();?>"><span><?php _e('Read More', 'juliette-wp');?></span><i class="fas fa-long-arrow-alt-right"></i></a>
</div>

 